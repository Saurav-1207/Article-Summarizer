import linkIcon from './link.svg'
import loader from './loader.svg'
import copy from './copy.svg'
import logo from './logo.svg'
import tick from './tick.svg'

export {
    linkIcon,
    loader,
    copy,
    logo,
    tick
}